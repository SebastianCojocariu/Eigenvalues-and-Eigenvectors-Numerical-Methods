function P=ValoriPolinoame(d,s,val_lambda)
%calculam valorile lui lambda in polinoamele construite(polinoame Sturm)
%cu mentiunea ca indicele incepe de la 1 si nu de la 0
[n]=length(d);
P(1)=1;
P(2)=d(1)-val_lambda;
for i=3:n+1
P(i)=(d(i-1)-val_lambda)*P(i-1)-s(i-2)^2*P(i-2);
endfor
endfunction