function [limita_inf,limita_sup]=LimiteValProprii(d,s)
%calculam vectorul t care retine suma valorilor absolute(fara elementul de pe diag principala) pentru fiecare linie a matricei;
n=length(d);
t(1)=abs(s(1));
t(n)=abs(s(n-1));
for i=2:n-1
 t(i)=abs(s(i-1))+abs(s(i));
endfor
%luam primele valori pentru limite;
limita_inf=d(1)-t(1);
limita_sup=d(1)+t(1);

%cu o singura parcurgere verificam daca limitele sunt cele mai bine(daca sunt cele mai mici,respectiv cele mai mari),altfel le schimbam.
for i=2:n
  x=d(i)-t(i);
  y=d(i)+t(i);
  if limita_inf>x
    limita_inf=x;
  endif
  
  if limita_sup<y
    limita_sup=y;
  endif
 endfor

endfunction 