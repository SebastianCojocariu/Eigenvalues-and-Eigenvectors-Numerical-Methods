function numvp=NrValProprii(d,s,val_lambda)
%generam vectorul de valori pentru valoarea lambda data
v=ValoriPolinoame(d,s,val_lambda);
[n]=length(v);
numvp=0;
%de fiecare daca cand semnul a 2 termeni alaturati e diferit
%sau cel de dupa el e 0 incrementam numvp;
for i=1:n-1
  if(v(i)*v(i+1)<0||v(i+1)==0)
    numvp++;
  endif
 endfor
 
endfunction