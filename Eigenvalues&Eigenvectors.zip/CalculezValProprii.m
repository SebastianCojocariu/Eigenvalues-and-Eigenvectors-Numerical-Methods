function vp=CalculezValProprii(d,s,m,tol)
%Generam intervalele in care se gasesc primele m valori proprii
r=IntervaleValProprii(d,s,m);
%daca m <length(d)=>m=length(d);
if(m>length(d));
m=length(d);
endif

n=length(d);
%pentru fiecare interval consecutiv( adica (r(i),r(i+1))) luam mijlocul
%generam valoarea P_n(mij) si in functie de pozitia fata de 0
%schimbam r(i) sau r(i+1) cu mij.Procedeul se repeta pana cand s-a atins toleranta
%OBS:nu lucram direct pe vectorul r,ci ne trebuie un alt vector intrucat pot exista erori
%la trecerea de la un interval la altul.
for i=1:m
vp1(i)=r(i);
vp1(i+1)=r(i+1);
vp(i)=(vp1(i)+vp1(i+1))/2;
  while vp1(i+1)-vp1(i)>tol/2;
   mij=(vp1(i)+vp1(i+1))/2;
  val1=ValoriPolinoame(d,s,mij);
  val2=ValoriPolinoame(d,s,vp1(i));
  val3=ValoriPolinoame(d,s,vp1(i+1));
  if(val1(n+1)*val2(n+1)<0)
    vp1(i+1)=mij;
    vp(i)=mij;
  else 
    vp1(i)=mij;
    vp(i)=mij;
  endif
  
  endwhile
  
endfor
 
 
  endfunction
  