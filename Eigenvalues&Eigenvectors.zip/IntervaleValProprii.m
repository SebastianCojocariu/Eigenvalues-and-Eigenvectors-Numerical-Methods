function r=IntervaleValProprii(d,s,m)
%Daca m e mai mare ca dimeniunea lui d il facem pe m=length(d)
if(m>length(d))
  m=length(d);
endif
%apelam functia LimiteValProprii
[limita_inf limita_sup]=LimiteValProprii(d,s);
r(1)=limita_inf;
r(m+2)=limita_sup;
%Se scrie algoritmul conform indicatiei de rezolvare
for k=m:-1:1
  mij=(r(1)+r(k+2))/2;
  h=(r(k+2)-r(1))/2;
  do
  numvp=NrValProprii(d,s,mij);
  h=h/2;
  if(numvp<k)
    mij=mij+h;
  elseif(numvp>k)
    mij=mij-h;
  endif
  until(numvp==k);
  r(k+1)=mij;
  
endfor
%stergem ultimul element(cel pe care l am folosit doar pt a-l genera pe r(m+1));
r(m+2)=[];
endfunction

