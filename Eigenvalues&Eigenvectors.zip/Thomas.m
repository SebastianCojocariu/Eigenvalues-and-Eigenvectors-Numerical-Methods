function [x]=Thomas(diag,diag_inf,diag_sup,b)
%Functia de rezolvare a unui sistem tridiagonal(metoda Thomas);
n=length(diag);
a=zeros(n,1);
x=zeros(n,1);
x(1)=b(1)/diag(1);
c=diag(1);


for i=2:n
  a(i-1)=diag_sup(i-1)/c;
  c=diag(i)-diag_inf(i)*a(i-1);
  x(i)=( b(i) -diag_inf(i)*x(i-1))/c;
endfor

for i=n-1:-1:1
  x(i)=x(i)-a(i)*x(i+1);
endfor
