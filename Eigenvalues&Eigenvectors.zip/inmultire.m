function [v]=inmultire(d,s,y)
%inmulteste o matrice tridiagonala simetrica(cu diag d si diag superioara s) cu un vector y;
%rezultatul se memoreaza in vectorul v(vector coloana);
n=length(d);
v=zeros(n,1);
v(1)=d(1)*y(1)+s(1)*y(2);
for i=2:n-1
  v(i)=s(i-1)*y(i-1)+d(i)*y(i)+s(i)*y(i+1);
endfor
v(n)=s(n-1)*y(n-1)+d(n)*y(n);

endfunction