function [valp vecp]=PutereInv(d,s,h,y,maxIter,tol)
   %Calculeaza o vp si vectorul asociat ei prin metoda puterii inverse;
   %Se urmaresc pasii din indicatiile de rezolvare(alaturi de pseudocodul din lab07);
  for k=1:maxIter
    z=Thomas((d-h),[0 s],[s 0],y);%solutia (A-hI_n)z=y;
    y=z/norm(z);
    vecp=y;%vecp ia valoarea lui y
    h=y'*inmultire(d,s,y);  %h=y'*A*y;
    valp=h;%valp ia valoarea lui h
    %daca se atinge toleranta, se iese din for;
    
      if(norm(inmultire(d,s,vecp)-valp*vecp)<tol)
        break;
      endif
    
  endfor  
 
endfunction